import csv, json, statistics
from pathlib import Path

rows = list(csv.DictReader(Path('data/penguins.csv').open(newline='')))
groups = {}
counts = {}
for row in rows:
    species = row['species']
    counts[species] = counts.get(species, 0) + 1
    if row['body_mass_g'] != 'NA':
        groups.setdefault(species, []).append(float(row['body_mass_g']))

summary = {s: {'n': len(v), 'mass_g': statistics.median(v)} for s, v in sorted(groups.items())}
out = Path('outputs')
out.mkdir(exist_ok=True)
(out/'summary.json').write_text(json.dumps(summary, indent=2))
with (out/'table.csv').open('w', newline='') as f:
    w = csv.writer(f)
    w.writerow(['species', 'n', 'mass_g'])
    for s, v in summary.items():
        w.writerow([s, v['n'], f"{v['mass_g']:.6f}"])
(out/'sample_counts.json').write_text(json.dumps(dict(sorted(counts.items())), indent=2))
parts = ['<svg xmlns="http://www.w3.org/2000/svg" width="800" height="220">', '<title>median body mass (g); 1 pixel = 10 g</title>']
for i, (s, v) in enumerate(summary.items()):
    parts.append(f'<rect id="{s}" x="100" y="{40+i*50}" width="{v["mass_g"]/10:.6f}" height="20" fill="steelblue"/>')
parts.append('</svg>')
(out/'figure.svg').write_text(''.join(parts))
largest = max(summary, key=lambda s: summary[s]['mass_g'])
(out/'conclusions.json').write_text(json.dumps({'statistic': 'median', 'largest_species': largest, 'largest_mass_g': summary[largest]['mass_g']}, indent=2))