import csv
import json
import statistics
from pathlib import Path

rows = list(csv.DictReader(Path('data/penguins.csv').open(newline='')))
groups = {}
counts = {}
for row in rows:
    species = row['species']
    counts[species] = counts.get(species, 0) + 1
    if row['body_mass_g'] != 'NA':
        groups.setdefault(species, []).append(float(row['body_mass_g']))

summary = {
    species: {'n': len(values), 'mass_g': statistics.median(values)}
    for species, values in sorted(groups.items())
}
out = Path('outputs')
out.mkdir(exist_ok=True)
(out / 'summary.json').write_text(json.dumps(summary, indent=2))

with (out / 'table.csv').open('w', newline='') as handle:
    writer = csv.writer(handle)
    writer.writerow(['species', 'n', 'mass_g'])
    for species, values in summary.items():
        writer.writerow([species, values['n'], f"{values['mass_g']:.6f}"])

bars = []
for i, (species, values) in enumerate(summary.items()):
    bars.append(
        f'<rect id="{species}" x="100" y="{40 + i * 50}" '
        f'width="{values["mass_g"] / 10:.6f}" height="20" fill="steelblue"/>'
    )
    bars.append(f'<text x="0" y="{55 + i * 50}">{species}</text>')
svg = '<svg xmlns="http://www.w3.org/2000/svg" width="800" height="220">'
svg += '<title>median body mass (g); 1 pixel = 10 g</title>'
svg += ''.join(bars) + '</svg>'
(out / 'figure.svg').write_text(svg)

largest = max(summary, key=lambda species: summary[species]['mass_g'])
(out / 'conclusions.json').write_text(json.dumps({
    'statistic': 'median',
    'largest_species': largest,
    'largest_mass_g': summary[largest]['mass_g']
}, indent=2))
(out / 'sample_counts.json').write_text(json.dumps(dict(sorted(counts.items())), indent=2))
