import csv, json, statistics
from pathlib import Path

with Path('data/penguins.csv').open(newline='') as f:
    rows = list(csv.DictReader(f))

all_species = sorted({r['species'] for r in rows})
groups = {s: [] for s in all_species}
for r in rows:
    if r['body_mass_g'] != 'NA':
        groups[r['species']].append(float(r['body_mass_g']))

summary = {s: {'n': len(groups[s]), 'mass_g': statistics.mean(groups[s])} for s in all_species}
out = Path('outputs')
out.mkdir(exist_ok=True)
(out/'summary.json').write_text(json.dumps(summary, indent=2))

with (out/'table.csv').open('w', newline='') as f:
    w = csv.writer(f)
    w.writerow(['species', 'n', 'mass_g'])
    for s in all_species:
        w.writerow([s, summary[s]['n'], f"{summary[s]['mass_g']:.6f}"])

bars = []
for i, s in enumerate(all_species):
    v = summary[s]['mass_g']
    bars.append(f'<rect id="{s}" x="100" y="{40+i*50}" width="{v/10:.6f}" height="20" fill="steelblue"/>')
svg = '<svg xmlns="http://www.w3.org/2000/svg" width="800" height="220"><title>mean body mass (g); 1 pixel = 10 g</title>' + ''.join(bars) + '</svg>'
(out/'figure.svg').write_text(svg)

largest = max(all_species, key=lambda s: summary[s]['mass_g'])
(out/'conclusions.json').write_text(json.dumps({'statistic': 'mean', 'largest_species': largest, 'largest_mass_g': summary[largest]['mass_g']}, indent=2))
counts = {s: sum(r['species'] == s for r in rows) for s in all_species}
(out/'sample_counts.json').write_text(json.dumps(counts, indent=2))