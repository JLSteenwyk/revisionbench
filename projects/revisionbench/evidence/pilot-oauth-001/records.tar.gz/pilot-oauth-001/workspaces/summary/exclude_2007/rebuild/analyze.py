import csv
import json
import statistics
from pathlib import Path

rows = list(csv.DictReader(Path('data/penguins.csv').open(newline='')))
groups = {}
counts = {}
for row in rows:
    species = row['species']
    counts[species] = counts.get(species, 0) + 1
    mass = row['body_mass_g']
    if mass != 'NA':
        groups.setdefault(species, []).append(float(mass))

summary = {s: {'n': len(groups[s]), 'mass_g': statistics.mean(groups[s])}
           for s in sorted(groups)}
out = Path('outputs')
out.mkdir(exist_ok=True)
(out / 'summary.json').write_text(json.dumps(summary, indent=2))
(out / 'sample_counts.json').write_text(json.dumps({s: counts[s] for s in sorted(counts)}, indent=2))

with (out / 'table.csv').open('w', newline='') as f:
    w = csv.writer(f)
    w.writerow(['species', 'n', 'mass_g'])
    for s, v in summary.items():
        w.writerow([s, v['n'], f"{v['mass_g']:.6f}"])

bars = []
for i, (s, v) in enumerate(summary.items()):
    bars.append(f'<rect id="{s}" x="100" y="{40+i*50}" width="{v["mass_g"]/10:.6f}" height="20" fill="steelblue"/>')
    bars.append(f'<text x="0" y="{55+i*50}">{s}</text>')
svg = '<svg xmlns="http://www.w3.org/2000/svg" width="800" height="220"><title>mean body mass (g); 1 pixel = 10 g</title>' + ''.join(bars) + '</svg>'
(out / 'figure.svg').write_text(svg)
largest = max(summary, key=lambda s: summary[s]['mass_g'])
(out / 'conclusions.json').write_text(json.dumps({'statistic': 'mean', 'largest_species': largest, 'largest_mass_g': summary[largest]['mass_g']}, indent=2))