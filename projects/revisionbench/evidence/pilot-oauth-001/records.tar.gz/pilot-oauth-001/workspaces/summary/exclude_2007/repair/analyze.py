import csv
import json
from pathlib import Path
from statistics import mean

rows = list(csv.DictReader(Path('data/penguins.csv').open(newline='')))
rows = [r for r in rows if r.get('year') != '2007']
values = {}
counts = {}
for row in rows:
    species = row['species']
    counts[species] = counts.get(species, 0) + 1
    mass = row.get('body_mass_g', 'NA')
    if mass != 'NA':
        values.setdefault(species, []).append(float(mass))

summary = {s: {'n': len(values[s]), 'mass_g': mean(values[s])} for s in sorted(values)}
out = Path('outputs')
out.mkdir(exist_ok=True)
(out / 'summary.json').write_text(json.dumps(summary, indent=2))
with (out / 'table.csv').open('w', newline='') as f:
    w = csv.writer(f)
    w.writerow(['species', 'n', 'mass_g'])
    for s, v in summary.items():
        w.writerow([s, v['n'], f"{v['mass_g']:.6f}"])
(out / 'sample_counts.json').write_text(json.dumps(counts, indent=2))
largest = max(summary, key=lambda s: summary[s]['mass_g'])
(out / 'conclusions.json').write_text(json.dumps({'statistic': 'mean', 'largest_species': largest, 'largest_mass_g': summary[largest]['mass_g']}, indent=2))
rects = []
for i, (s, v) in enumerate(summary.items()):
    rects.append(f'<rect id="{s}" x="100" y="{40+i*50}" width="{v["mass_g"]/10:.6f}" height="20" fill="steelblue"/>')
(out / 'figure.svg').write_text('<svg xmlns="http://www.w3.org/2000/svg" width="800" height="220"><title>mean body mass (g); 1 pixel = 10 g</title>' + ''.join(rects) + '</svg>')