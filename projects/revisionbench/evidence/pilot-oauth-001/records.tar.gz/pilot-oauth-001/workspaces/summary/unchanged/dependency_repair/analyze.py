import csv
import json
from pathlib import Path
import statistics

with Path('data/penguins.csv').open(newline='') as f:
    rows = list(csv.DictReader(f))

counts = {}
groups = {}
for row in rows:
    species = row['species']
    counts[species] = counts.get(species, 0) + 1
    if row['body_mass_g'] != 'NA':
        groups.setdefault(species, []).append(float(row['body_mass_g']))

summary = {}
for species in sorted(groups):
    values = groups[species]
    summary[species] = {'n': len(values), 'mass_g': statistics.mean(values)}

out = Path('outputs')
out.mkdir(exist_ok=True)
(out / 'summary.json').write_text(json.dumps(summary, indent=2))

with (out / 'table.csv').open('w', newline='') as f:
    writer = csv.writer(f)
    writer.writerow(['species', 'n', 'mass_g'])
    for species, value in summary.items():
        writer.writerow([species, value['n'], f"{value['mass_g']:.6f}"])

bars = []
for i, (species, value) in enumerate(summary.items()):
    bars.append(f'<rect id="{species}" x="100" y="{40 + i * 50}" width="{value["mass_g"] / 10:.6f}" height="20" fill="steelblue"/>')

svg = '<svg xmlns="http://www.w3.org/2000/svg" width="800" height="220"><title>mean body mass (g); 1 pixel = 10 g</title>' + ''.join(bars) + '</svg>'
(out / 'figure.svg').write_text(svg)

largest = max(summary, key=lambda species: summary[species]['mass_g'])
(out / 'conclusions.json').write_text(json.dumps({
    'statistic': 'mean',
    'largest_species': largest,
    'largest_mass_g': summary[largest]['mass_g']
}, indent=2))
(out / 'sample_counts.json').write_text(json.dumps(dict(sorted(counts.items())), indent=2))