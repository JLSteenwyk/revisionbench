import csv
import json
from pathlib import Path

predictor = 'flipper_length_mm'
probes = [180.0, 200.0, 220.0]
rows = list(csv.DictReader(Path('data/penguins.csv').open(newline='')))
pairs = [(float(r[predictor]), float(r['body_mass_g'])) for r in rows
          if r[predictor] != 'NA' and r['body_mass_g'] != 'NA']
xs = [p[0] for p in pairs]
ys = [p[1] for p in pairs]
mx = sum(xs) / len(xs)
my = sum(ys) / len(ys)
slope = sum((x - mx) * (y - my) for x, y in pairs) / sum((x - mx) ** 2 for x in xs)
intercept = my - slope * mx
pred = lambda x: intercept + slope * x
ss_res = sum((y - pred(x)) ** 2 for x, y in pairs)
ss_tot = sum((y - my) ** 2 for y in ys)
fit = {'n': len(pairs), 'slope': slope, 'intercept': intercept,
       'r_squared': 1.0 - ss_res / ss_tot}
out = Path('outputs')
out.mkdir(exist_ok=True)
(out / 'fit.json').write_text(json.dumps(fit, indent=2))
with (out / 'predictions.csv').open('w', newline='') as f:
    w = csv.writer(f)
    w.writerow(['flipper_length', 'predicted_mass_g'])
    for x in probes:
        w.writerow([x, format(pred(x), '.12f')])
y1 = 280.0 - pred(probes[0]) / 25.0
y2 = 280.0 - pred(probes[-1]) / 25.0
svg = ('<svg xmlns="http://www.w3.org/2000/svg" width="640" height="300">'
       '<title>OLS body mass (g) versus flipper length (mm)</title>'
       f'<line id="fit" x1="50" x2="590" y1="{y1:.12f}" y2="{y2:.12f}" />'
       '</svg>')
(out / 'figure.svg').write_text(svg)
(out / 'conclusions.json').write_text(json.dumps({
    'predictor': predictor, 'unit': 'mm',
    'association': 'positive' if slope > 0 else 'negative' if slope < 0 else 'zero',
    'model_n': len(pairs)}))
counts = {}
for r in rows:
    counts[r['species']] = counts.get(r['species'], 0) + 1
(out / 'sample_counts.json').write_text(json.dumps(dict(sorted(counts.items()))))