import csv, json, math
from pathlib import Path

predictor = 'flipper_length_mm'
probes = [180, 200, 220]
with Path('data/penguins.csv').open(newline='') as f:
    rows = list(csv.DictReader(f))

pairs = [(float(r[predictor]), float(r['body_mass_g'])) for r in rows
         if r[predictor] != 'NA' and r['body_mass_g'] != 'NA']
n = len(pairs)
mx = sum(x for x, y in pairs) / n
my = sum(y for x, y in pairs) / n
ssx = sum((x - mx) ** 2 for x, y in pairs)
sxy = sum((x - mx) * (y - my) for x, y in pairs)
slope = sxy / ssx
intercept = my - slope * mx
pred = lambda x: intercept + slope * x
residual = sum((y - pred(x)) ** 2 for x, y in pairs)
total = sum((y - my) ** 2 for x, y in pairs)
r_squared = 1 - residual / total

out = Path('outputs')
out.mkdir(exist_ok=True)
(out / 'fit.json').write_text(json.dumps({
    'n': n, 'slope': slope, 'intercept': intercept, 'r_squared': r_squared
}, indent=2))

with (out / 'predictions.csv').open('w', newline='') as f:
    w = csv.writer(f)
    w.writerow(['flipper_length', 'predicted_mass_g'])
    for x in probes:
        w.writerow([x, format(pred(x), '.9f')])

p0, p2 = pred(probes[0]), pred(probes[-1])
(out / 'figure.svg').write_text(
    '<svg xmlns="http://www.w3.org/2000/svg" width="640" height="300">'
    '<title>OLS body mass (g) versus flipper length (mm)</title>'
    f'<line id="fit" x1="50" x2="590" y1="{280-p0/25:.9f}" '
    f'y2="{280-p2/25:.9f}" stroke="steelblue"/>'
    '</svg>'
)

(out / 'conclusions.json').write_text(json.dumps({
    'predictor': predictor, 'unit': 'mm',
    'association': 'positive' if slope > 0 else 'negative' if slope < 0 else 'zero',
    'model_n': n
}))
counts = {}
for r in rows:
    counts[r['species']] = counts.get(r['species'], 0) + 1
(out / 'sample_counts.json').write_text(json.dumps(dict(sorted(counts.items()))))
