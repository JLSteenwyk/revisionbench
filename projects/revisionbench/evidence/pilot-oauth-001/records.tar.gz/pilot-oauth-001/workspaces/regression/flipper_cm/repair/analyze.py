import csv
import json
from pathlib import Path

predictor = 'flipper_length_cm'
unit = 'cm'
probes = [18.0, 20.0, 22.0]

with Path('data/penguins.csv').open(newline='') as f:
    rows = list(csv.DictReader(f))

pairs = [(float(r[predictor]), float(r['body_mass_g'])) for r in rows
         if r[predictor] != 'NA' and r['body_mass_g'] != 'NA']
x = [p[0] for p in pairs]
y = [p[1] for p in pairs]
n = len(pairs)
mx = sum(x) / n
my = sum(y) / n
sxx = sum((v - mx) ** 2 for v in x)
sxy = sum((a - mx) * (b - my) for a, b in pairs)
slope = sxy / sxx
intercept = my - slope * mx
predicted = [intercept + slope * v for v in x]
residual = sum((b - p) ** 2 for b, p in zip(y, predicted))
total = sum((b - my) ** 2 for b in y)
r_squared = 1.0 - residual / total

out = Path('outputs')
out.mkdir(exist_ok=True)
(out / 'fit.json').write_text(json.dumps({
    'n': n, 'slope': slope, 'intercept': intercept, 'r_squared': r_squared
}, indent=2))

with (out / 'predictions.csv').open('w', newline='') as f:
    w = csv.writer(f)
    w.writerow(['flipper_length', 'predicted_mass_g'])
    for v in probes:
        w.writerow([v, f'{intercept + slope * v:.9f}'])

p0 = intercept + slope * probes[0]
p2 = intercept + slope * probes[-1]
(out / 'figure.svg').write_text(
    '<svg xmlns="http://www.w3.org/2000/svg" width="640" height="300">'
    '<title>OLS body mass (g) versus flipper length (cm)</title>'
    f'<line id="fit" x1="50" x2="590" y1="{280-p0/25:.9f}" '
    f'y2="{280-p2/25:.9f}" stroke="steelblue"/>'
    '<text x="30" y="295">18.0 cm</text><text x="530" y="295">22.0 cm</text></svg>'
)

(out / 'conclusions.json').write_text(json.dumps({
    'predictor': predictor,
    'unit': unit,
    'association': 'positive' if slope > 0 else 'negative' if slope < 0 else 'zero',
    'model_n': n
}))

counts = {}
for r in rows:
    counts[r['species']] = counts.get(r['species'], 0) + 1
(out / 'sample_counts.json').write_text(json.dumps(dict(sorted(counts.items()))))
