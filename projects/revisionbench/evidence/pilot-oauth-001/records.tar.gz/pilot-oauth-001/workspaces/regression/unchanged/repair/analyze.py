import csv
import json
from pathlib import Path

predictor = 'flipper_length_mm'
probes = [180, 200, 220]

with Path('data/penguins.csv').open(newline='') as f:
    rows = list(csv.DictReader(f))

pairs = []
counts = {}
for row in rows:
    species = row['species']
    counts[species] = counts.get(species, 0) + 1
    if row[predictor] != 'NA' and row['body_mass_g'] != 'NA':
        pairs.append((float(row[predictor]), float(row['body_mass_g'])))

n = len(pairs)
mean_x = sum(x for x, y in pairs) / n
mean_y = sum(y for x, y in pairs) / n
ss_xx = sum((x - mean_x) ** 2 for x, y in pairs)
ss_xy = sum((x - mean_x) * (y - mean_y) for x, y in pairs)
slope = ss_xy / ss_xx
intercept = mean_y - slope * mean_x
predictions = [intercept + slope * x for x in probes]
ss_res = sum((y - (intercept + slope * x)) ** 2 for x, y in pairs)
ss_tot = sum((y - mean_y) ** 2 for x, y in pairs)
r_squared = 1.0 - ss_res / ss_tot

out = Path('outputs')
out.mkdir(exist_ok=True)
(out / 'fit.json').write_text(json.dumps({
    'n': n, 'slope': slope, 'intercept': intercept, 'r_squared': r_squared
}, indent=2))

with (out / 'predictions.csv').open('w', newline='') as f:
    w = csv.writer(f)
    w.writerow(['flipper_length', 'predicted_mass_g'])
    for x, prediction in zip(probes, predictions):
        w.writerow([x, f'{prediction:.9f}'])

y1 = 280 - predictions[0] / 25
y2 = 280 - predictions[-1] / 25
(out / 'figure.svg').write_text(
    '<svg xmlns="http://www.w3.org/2000/svg" width="640" height="300">'
    '<title>OLS body mass (g) versus flipper length (mm)</title>'
    f'<line id="fit" x1="50" x2="590" y1="{y1:.9f}" y2="{y2:.9f}" />'
    '</svg>'
)

(out / 'conclusions.json').write_text(json.dumps({
    'predictor': predictor,
    'unit': 'mm',
    'association': 'positive' if slope > 0 else 'negative' if slope < 0 else 'zero',
    'model_n': n
}))
(out / 'sample_counts.json').write_text(json.dumps(dict(sorted(counts.items()))))
