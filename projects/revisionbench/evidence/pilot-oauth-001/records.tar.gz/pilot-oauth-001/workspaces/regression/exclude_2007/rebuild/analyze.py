import csv
import json
from pathlib import Path

predictor = 'flipper_length_mm'
probes = [180, 200, 220]
rows = list(csv.DictReader(Path('data/penguins.csv').open(newline='')))
pairs = [(float(r[predictor]), float(r['body_mass_g'])) for r in rows if r[predictor] != 'NA' and r['body_mass_g'] != 'NA']
x = [p[0] for p in pairs]
y = [p[1] for p in pairs]
n = len(pairs)
mx = sum(x) / n
my = sum(y) / n
sxx = sum((v - mx) ** 2 for v in x)
sxy = sum((v - mx) * (w - my) for v, w in pairs)
slope = sxy / sxx
intercept = my - slope * mx
pred = lambda v: intercept + slope * v
ssr = sum((w - pred(v)) ** 2 for v, w in pairs)
sst = sum((w - my) ** 2 for w in y)
fit = {'n': n, 'slope': slope, 'intercept': intercept, 'r_squared': 1 - ssr / sst}
out = Path('outputs')
out.mkdir(exist_ok=True)
(out / 'fit.json').write_text(json.dumps(fit, indent=2))
with (out / 'predictions.csv').open('w', newline='') as f:
    w = csv.writer(f)
    w.writerow(['flipper_length', 'predicted_mass_g'])
    for v in probes:
        w.writerow([v, f'{pred(v):.9f}'])
first, last = pred(probes[0]), pred(probes[-1])
svg = '<svg xmlns="http://www.w3.org/2000/svg" width="640" height="300">' + '<title>OLS body mass (g) versus flipper length (mm)</title>' + f'<line id="fit" x1="50" x2="590" y1="{280-first/25:.9f}" y2="{280-last/25:.9f}" stroke="steelblue"/>' + '</svg>'
(out / 'figure.svg').write_text(svg)
(out / 'conclusions.json').write_text(json.dumps({'predictor': predictor, 'unit': 'mm', 'association': 'positive' if slope > 0 else 'negative' if slope < 0 else 'zero', 'model_n': n}))
counts = {}
for r in rows:
    counts[r['species']] = counts.get(r['species'], 0) + 1
(out / 'sample_counts.json').write_text(json.dumps(dict(sorted(counts.items()))))