import csv
import json
from pathlib import Path

rows = list(csv.DictReader(Path('data/penguins.csv').open(newline='')))
pairs = [(float(r['flipper_length_cm']), float(r['body_mass_g'])) for r in rows if r['flipper_length_cm'] != 'NA' and r['body_mass_g'] != 'NA']
x = [p[0] for p in pairs]
y = [p[1] for p in pairs]
mx = sum(x) / len(x)
my = sum(y) / len(y)
sxx = sum((v - mx) ** 2 for v in x)
sxy = sum((a - mx) * (b - my) for a, b in pairs)
slope = sxy / sxx
intercept = my - slope * mx
pred = lambda v: intercept + slope * v
residual = sum((b - pred(a)) ** 2 for a, b in pairs)
total = sum((b - my) ** 2 for b in y)
fit = {'n': len(pairs), 'slope': slope, 'intercept': intercept, 'r_squared': 1 - residual / total}
out = Path('outputs')
out.mkdir(exist_ok=True)
(out / 'fit.json').write_text(json.dumps(fit, indent=2))
probes = [18, 20, 22]
with (out / 'predictions.csv').open('w', newline='') as f:
    w = csv.writer(f)
    w.writerow(['flipper_length', 'predicted_mass_g'])
    for v in probes:
        w.writerow([v, f'{pred(v):.9f}'])
first, last = pred(probes[0]), pred(probes[-1])
(out / 'figure.svg').write_text(f'<svg xmlns="http://www.w3.org/2000/svg" width="640" height="300"><title>OLS body mass (g) versus flipper length (cm)</title><line id="fit" x1="50" y1="{280-first/25:.9f}" x2="590" y2="{280-last/25:.9f}" stroke="steelblue"/></svg>')
(out / 'conclusions.json').write_text(json.dumps({'predictor': 'flipper_length_cm', 'unit': 'cm', 'association': 'positive' if slope > 0 else 'negative' if slope < 0 else 'zero', 'model_n': len(pairs)}))
counts = {}
for r in rows:
    counts[r['species']] = counts.get(r['species'], 0) + 1
(out / 'sample_counts.json').write_text(json.dumps(dict(sorted(counts.items()))))