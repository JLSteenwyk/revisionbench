import csv
import json
from pathlib import Path

predictor = 'flipper_length_cm'
unit = 'cm'
probes = [18.0, 20.0, 22.0]

with Path('data/penguins.csv').open(newline='') as f:
    rows = list(csv.DictReader(f))

pairs = [(float(r[predictor]), float(r['body_mass_g'])) for r in rows
         if r[predictor] != 'NA' and r['body_mass_g'] != 'NA']

n = len(pairs)
xs = [p[0] for p in pairs]
ys = [p[1] for p in pairs]
mean_x = sum(xs) / n
mean_y = sum(ys) / n
ssx = sum((x - mean_x) ** 2 for x in xs)
sxy = sum((x - mean_x) * (y - mean_y) for x, y in pairs)
slope = sxy / ssx
intercept = mean_y - slope * mean_x
pred = lambda x: intercept + slope * x
residual = sum((y - pred(x)) ** 2 for x, y in pairs)
total = sum((y - mean_y) ** 2 for y in ys)
r_squared = 1 - residual / total

out = Path('outputs')
out.mkdir(exist_ok=True)
(out / 'fit.json').write_text(json.dumps({
    'n': n, 'slope': slope, 'intercept': intercept, 'r_squared': r_squared
}, indent=2))

with (out / 'predictions.csv').open('w', newline='') as f:
    w = csv.writer(f)
    w.writerow(['flipper_length', 'predicted_mass_g'])
    for x in probes:
        w.writerow([x, f'{pred(x):.9f}'])

first = pred(probes[0])
last = pred(probes[-1])
(out / 'figure.svg').write_text(
    '<svg xmlns="http://www.w3.org/2000/svg" width="640" height="300">'
    '<title>OLS body mass (g) versus flipper length (cm)</title>'
    f'<line id="fit" x1="50" x2="590" y1="{280-first/25:.9f}" '
    f'y2="{280-last/25:.9f}" stroke="steelblue"/>'
    '</svg>'
)

(out / 'conclusions.json').write_text(json.dumps({
    'predictor': predictor,
    'unit': unit,
    'association': 'positive' if slope > 0 else 'negative' if slope < 0 else 'zero',
    'model_n': n
}))

counts = {}
for r in rows:
    counts[r['species']] = counts.get(r['species'], 0) + 1
(out / 'sample_counts.json').write_text(json.dumps(dict(sorted(counts.items()))))