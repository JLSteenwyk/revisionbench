raise RuntimeError('deliberate failure before refreshing retained outputs')
