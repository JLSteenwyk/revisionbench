raise RuntimeError('deliberate immutable execution-failure fixture')
