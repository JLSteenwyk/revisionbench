import csv,json,statistics
from pathlib import Path
rows=list(csv.DictReader(Path('data/penguins.csv').open()))
groups={}
for r in rows:
    if r['body_mass_g']!='NA': groups.setdefault(r['species'],[]).append(float(r['body_mass_g']))
summary={k:{'n':len(v),'mass_g':statistics.median(v)} for k,v in sorted(groups.items())}
out=Path('outputs'); out.mkdir(exist_ok=True)
(out/'summary.json').write_text(json.dumps(summary,indent=2))
with (out/'table.csv').open('w',newline='') as f:
 w=csv.writer(f); w.writerow(['species','n','mass_g'])
 for k,v in summary.items(): w.writerow([k,v['n'],f"{v['mass_g']:.6f}"])
bars=[]
for i,(k,v) in enumerate(summary.items()):
 bars.append(f'<rect id="{k}" x="100" y="{40+i*50}" width="{v["mass_g"]/10:.6f}" height="20" fill="steelblue"/>')
(out/'figure.svg').write_text('<svg xmlns="http://www.w3.org/2000/svg" width="800" height="220"><title>median body mass (g); 1 pixel = 10 g</title>'+''.join(bars)+'</svg>')
largest=max(summary,key=lambda k:summary[k]['mass_g'])
(out/'conclusions.json').write_text(json.dumps({'statistic':'median','largest_species':largest,'largest_mass_g':summary[largest]['mass_g']},indent=2))
counts={k:sum(r['species']==k for r in rows) for k in sorted(groups)}
(out/'sample_counts.json').write_text(json.dumps(counts,indent=2))